# abs.py 
def abs(x): 
   if x < 0: return -x 
   return x 
