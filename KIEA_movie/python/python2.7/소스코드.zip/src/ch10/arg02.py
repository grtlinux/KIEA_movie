# arg02.py
def printf(format, *args): 
    print format % args 
     
printf("I've spent %d days and %d night to do this", 6, 5) 
