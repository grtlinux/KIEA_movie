# for12.py
LL = [['one', 1], ['two', 2], ['three', 3]] 
for name, num in LL: 
    print name, num 
