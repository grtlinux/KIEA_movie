# for09.py
lt = [('one', 1), ('two', 2), ('three', 3)] 
for t in lt: 
    print 'name=', t[0], 'num=', t[1] 
