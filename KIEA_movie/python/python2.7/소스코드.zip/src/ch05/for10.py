# for10.py
for t in lt: 
    print 'name=%s, num=%s' % t 
