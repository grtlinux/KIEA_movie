# file : arg.py 
import sys 
print sys.argv 
