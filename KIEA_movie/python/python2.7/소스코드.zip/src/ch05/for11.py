# for11.py
for name, num in lt: 
    print name, num 
