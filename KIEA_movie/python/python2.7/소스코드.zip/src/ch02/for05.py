# for05.py
for x in range(2, 4):
    for y in range(2, 10):
        print '%2d * %2d = %2d' % (x, y, x*y)
    print
