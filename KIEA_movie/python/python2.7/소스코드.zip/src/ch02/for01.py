# for01.py
for x in range(10):
    if x > 3: break  # x가 3보다 크면 for 블록을 벗어난다.
    print x
print 'done'
