# for04.py
for x in range(10):
    break
    print x,   # 콤마로 줄을 바꾸지 않는다.
else:
    print 'else block'
print 'done'
