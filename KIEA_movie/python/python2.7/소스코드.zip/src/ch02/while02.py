# while02.py
a = 0 
while a < 10: 
    a = a + 1 
    if a < 3: continue 
    if a > 10: break 
else: 
    print 'else block' 
print 'done' 
