# for02.py
for x in range(10):
    if x < 8: continue  # x < 8 이면 for 문으로 다시 올라간다.
    print x
print 'done'
