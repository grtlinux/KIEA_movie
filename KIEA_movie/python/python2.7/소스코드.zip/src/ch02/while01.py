# while01.py
sum = 0 
a = 0 
while a < 10: 
    a = a + 1 
    sum = sum + a 
print sum 
