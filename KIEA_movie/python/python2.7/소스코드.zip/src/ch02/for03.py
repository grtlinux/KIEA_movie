# for03.py
for x in range(10):
    print x,   # 콤마로 줄을 바꾸지 않는다.
else:
    print 'else block'
print 'done'
