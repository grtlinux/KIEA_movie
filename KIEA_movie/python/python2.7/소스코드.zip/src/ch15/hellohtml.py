#!/usr/local/bin/python

print "Content-Type: text/html\n\n"

print '''
<HTML>
<HEAD></HEAD>
<BODY>
<H2>이건 제목</H2>
Hello again,
<b>이건 굵은 글씨</b>
</BODY>
</HTML>
'''
