#!/usr/bin/python
 
print "Content-Type: text/plain\n\n"
 
print "Hello, Python!"  # print a test string
