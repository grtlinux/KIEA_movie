# file : name_attr_test.py 
def test(): 
    print "Python is becoming popular." 
     
if __name__ == "__main__" 
    test() 
