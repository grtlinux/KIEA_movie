# module02.py
a = 1 
b = 2 
 
gns = globals() 
print gns 
gns['c'] = 3   # 사전에 새 이름 추가 
print gns
