# FILE : mymath.py 
mypi = 3.14 
 
def add(a, b): 
    return a + b 
 
def area(r): 
    return mypi * r * r 
