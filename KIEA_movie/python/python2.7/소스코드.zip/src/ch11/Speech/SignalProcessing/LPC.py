#file : LPC.py

print 'LPC.py called..'
