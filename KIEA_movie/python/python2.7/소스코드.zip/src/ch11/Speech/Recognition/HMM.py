#file : HMM.py

def Train():
    pass

def LoadModel():
    pass

def SaveModel():
    pass
