# file : teststring1.py 
import string 
 
print 'test string1' 
string.a = 1 
 
import teststring2 
 
print 'test string1 done' 
