# FILE : mymath02.py 
mypi = 3.14 
 
def add(a, b): 
    return a + b 
 
def area(r): 
    return mypi * r * r 
 
print area(4.0) 
