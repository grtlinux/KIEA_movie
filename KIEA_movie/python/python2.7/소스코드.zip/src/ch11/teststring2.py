# file : teststring2.py 
import string 
 
print 'test string2' 
print string.a 
print 'test string2 done' 
