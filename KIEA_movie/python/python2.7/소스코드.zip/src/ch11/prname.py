# FILE : prname.py 
print __name__ 
