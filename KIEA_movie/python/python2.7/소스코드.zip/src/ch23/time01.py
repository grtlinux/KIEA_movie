# time01.py
import time

def delay(sec):
        time.sleep(sec)

print time.clock()
delay(3)
print time.clock()
