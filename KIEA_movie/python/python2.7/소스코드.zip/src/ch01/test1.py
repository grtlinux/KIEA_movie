execfile('modfile.py') 
print s 
print add(5,6) 
