#!/usr/bin/python 
# file : cal02.py 
import calendar 
calendar.prmonth(2001, 3) 
