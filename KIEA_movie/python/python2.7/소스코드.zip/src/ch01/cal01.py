# file : cal.py
import calendar
calendar.prmonth(2001, 3)
raw_input('Type Enter key..')  # 키보드 입력받는 명령
