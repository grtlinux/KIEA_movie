pi = 3.141592

def area(r):
        return pi * r * r

def boxarea(w, h):
        return w * h
