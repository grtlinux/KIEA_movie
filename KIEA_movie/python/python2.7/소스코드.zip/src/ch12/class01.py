
# class01.py 
class MyClass:  
    def set(self, v):  
        self.value = v  
    def put(self):  
        print self.value  
